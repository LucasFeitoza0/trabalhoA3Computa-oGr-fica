import { getColorIterator } from "../utils/colors/color.js"
import rects from "../utils/grids/grid01.js"

export default function(key, draw) {

    let nextColor = getColorIterator(key)

    for (let idx in rects) {
        let rect = rects[idx]
        let c = nextColor()
        let shape = key.next256() % 4
        if (shape == 0) {
            draw.square().size(square.width, square.height).move(square.x, square.y).fill(c)
        }
        if (shape == 1) {
            draw.triangle(triangle.width).move(triangle.x, triangle.y).fill(c)
        }
        if (shape == 2) {
            let x1 = polyline.x
            let y1 = polyline.y
            let x2 = polyline.x + polyline.width
            let y2 = polyline.y
            let x3 = polyline.x + polyline.width/2
            let y3 = polyline.y + polyline.height
            draw.polyline([x1, y1, x2, y2, x3, y3]).fill(c).opacity(0.5)
        }
        if (shape == 3) {
            let x1 = polyline.x
            let y1 = polyline.y + polyline.height
            let x2 = polyline.x + polyline.width
            let y2 = polyline.y + polyline.height
            let x3 = polyline.x + polyline.width/2
            let y3 = polyline.y + 0
            draw.polyline([x1, y1, x2, y2, x3, y3]).fill(c).opacity(0.6)
        }
    }
}
