
export default [
    //linha 1
    { x: 0, y: 0, width: 250, height: 250 },
    { x: 250, y: 0, width: 250, height: 250 },
    { x: 500, y: 0, width: 250, height: 250 },
    { x: 750, y: 0, width: 250, height: 250 },
    //linha 2
    { x: 0, y: 250, width: 250, height: 250 },
    { x: 0, y: 500, width: 250, height: 250 },
    //linha 3
    { x: 750, y: 250, width: 250, height: 250 },
    { x: 750, y: 500, width: 250, height: 250 },
    //linha 4
    { x: 0, y: 750, width: 250, height: 250 },
    { x: 250, y: 750, width: 250, height: 250 },
    { x: 500, y: 750, width: 250, height: 250 },
    { x: 750, y: 750, width: 250, height: 250 },
    //centro
    { x: 250, y: 250, width: 500, height: 500 },
]
