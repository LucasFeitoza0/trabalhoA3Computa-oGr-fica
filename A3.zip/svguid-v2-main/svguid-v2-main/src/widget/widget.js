import { getColorIterator } from "./utils/colors/color.js"
import sample from "./examples/widget00.js"
import blob from "./utils/blob/blob.js"
import shape from "./utils/shape/shape.js"

function widget(key, draw) {
    let nextColor = getColorIterator(key)
 
    draw.rect().size(500,500).move(1,1).fill(nextColor()).opacity(0.5)
    draw.rect().size(500,500).move(500,1).fill(nextColor()).opacity(0.5)
    draw.rect().size(500,500).move(1,500).fill(nextColor()).opacity(0.5)
    draw.rect().size(500,500).move(500,500).fill(nextColor()).opacity(0.5)

    let b = blob(key.next())
    b.fill(nextColor()).move(50,50).size(100)
    b.addTo(draw)
 
    let valor = key.next()
    console.log('valor',valor);
    let s = shape(valor)
    s.fill(nextColor()).move(200,0).size(250)
    s.addTo(draw)

    let s3 = shape(key.next())
    s3.fill(nextColor()).move(500,0).size(250).opacity(0.7)
    s3.addTo(draw)

    let s2 = shape(key.next())
    s2.fill("blue").move(600,500).size(450)
    s2.addTo(draw)

    // Descomente linha abaixo para ver exemplo 0
    //sample(key,draw)
}

export default widget