import { getColorIterator } from "../utils/colors/color.js"
import square from "../utils/grids/grid01.js"

export default function (key, draw) {

    let nextColor = getColorIterator(key)

    for (let idx in square) {
        let r = square[idx]
        draw.square().size(r.width, r.height).move(r.x,r.y).fill(nextColor())
    }
    
}
